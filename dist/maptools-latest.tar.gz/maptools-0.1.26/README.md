Very early library adds some useful function to work with maps and geospatial data in Python.

This is not ready for production, the API will definitely change and is unstable.
